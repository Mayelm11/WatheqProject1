import { HttpHeaderProvider } from './http-header-provider';
import { Injectable } from '@angular/core';
import { map, timeout } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable()
export class HttpServicesProvider {

  constructor(
    public http: HttpClient,
    private httpHeaderProvider: HttpHeaderProvider
  ) { }

  signIn(username: String, password: String): Observable<any> {
    return this.http.get<any>(environment.DOMAIN_URL + '/auth/login?username=' + username + "&password=" + password, { headers: this.httpHeaderProvider.getHeaderJson(), observe: 'response' })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  createCompany(obj: any): Observable<any> {
    return this.http.post(environment.DOMAIN_URL + '/company/insertCompany', obj, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }


}
