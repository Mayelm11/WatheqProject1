import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ReadOnlyValues } from './readonly-values';

@Injectable()
export class DataService implements OnDestroy {

    private emailSubject = new BehaviorSubject<string>('');
    // private emailCorrectSubject = new BehaviorSubject<boolean>(null);
    // emailCorrect = this.emailCorrectSubject.asObservable();
    private authTokenSubject = new BehaviorSubject<string>('');

    private userId: number;
    private userPhoneNumber: string;
    private userName: string;
    private userType: string;
    private userPictureToken: string;

    private createdProjectId: Number;

    constructor(
        private readOnlyValues: ReadOnlyValues
    ) { }

    ngOnDestroy() {
        this.emailSubject.unsubscribe();
        this.authTokenSubject.unsubscribe();
        // this.emailCorrectSubject.unsubscribe();
    }

    // *********************** Getters & Setters ************************* //
    setEmail(email: string) {
        this.emailSubject.next(email);
    }

    getEmail(): string {
        return this.emailSubject.getValue();
    }

    // setEmailCorrect(emailCorrect: boolean) {
    //     this.emailCorrectSubject.next(emailCorrect);
    // }

    // getEmailCorrect(): boolean {
    //     return this.emailCorrectSubject.getValue();
    // }

    getUserName(): string {
        return this.userName;
    }

    setUserName(userName: string) {
        this.userName = userName;
    }

    getUserType(): string {
        return this.userType;
    }

    setUserType(userType: string) {
        this.userType = userType;
    }

    getCreatedProjectId(): Number {
        return this.createdProjectId;
    }

    setCreatedProjectId(createdProjectId: Number) {
        this.createdProjectId = createdProjectId;
    }

    // *********************** Methods ************************* //

    SetUserData(UserDetails, authorizationToken) {
        this.userId = +UserDetails.userId;
        this.userPhoneNumber = UserDetails.userName;
        this.userName = UserDetails.name;
        this.userType = UserDetails.userType;
        this.userPictureToken = UserDetails.profilePictureToken;
    }

    clearUserData() {
        this.userId = null;
        this.userPhoneNumber = null;
        this.userName = null;
        this.userType = null;
        this.userPictureToken = null;
    }
}
