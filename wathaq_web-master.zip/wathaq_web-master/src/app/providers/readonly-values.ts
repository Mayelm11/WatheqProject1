
export class ReadOnlyValues {

    readonly welcomePage: String = "welcome";
    readonly loginPage: String = "login";
    readonly newAccount: String = "newaccount";

    readonly companies: String = "/admin/companies";
    readonly educational: String = "/admin/educational";

    readonly loggedIn: String = "logged-in";
}