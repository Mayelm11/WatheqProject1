import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { ActivatedRoute, Router, NavigationEnd, Event, Data } from '@angular/router';
import { AppRouter } from 'src/app/providers/app-router';
import { HttpServicesProvider } from 'src/app/providers/http-services/http-services-provider';
import { DataService } from 'src/app/providers/data-service';
import { NotificationService } from 'src/app/providers/notification-service';
import { LoadingProvider } from 'src/app/providers/loading-provider';
import { ReadOnlyValues } from 'src/app/providers/readonly-values';

export interface Options {
    heading?: string;
}

@Component({
    selector: 'app-layout',
    templateUrl: './admin-layout.component.html',
    styleUrls: ['./admin-layout.component.scss']
})

export class AdminLayoutComponent implements OnInit, OnDestroy, AfterViewInit {
    isMenuCollapsed: Boolean = false;
    applicationName: String = environment.applicationName;
    options: Options;
    private _subscription: Subscription;

    constructor(
        private titleService: Title,
        private router: Router,
        private route: ActivatedRoute,
        public appRouter: AppRouter,
        private httpServicesProvider: HttpServicesProvider,
        public dataService: DataService,
        private notificationService: NotificationService,
        private loadingProvider: LoadingProvider,
        public readOnlyValues: ReadOnlyValues
    ) {
    }

    ngOnInit() {
        this._subscription = this.router.events.pipe(filter((event: Event) => event instanceof NavigationEnd)).subscribe((event: NavigationEnd) => {
            this.runOnRouteChange();
        });
    }

    ngAfterViewInit(): void {
        setTimeout(() => this.runOnRouteChange());
    }

    ngOnDestroy() {
        this._subscription.unsubscribe();
    }

    runOnRouteChange() {
        this.route.children.forEach((route: ActivatedRoute) => {
            let activeRoute: ActivatedRoute = route;
            while (activeRoute.firstChild) {
                activeRoute = activeRoute.firstChild;
            }
            this.options = activeRoute.snapshot.data;
        });
        if (this.options) {
            if (this.options.hasOwnProperty('heading')) {
                this.setTitle(this.options.heading);
            }
        }
    }

    setTitle(newTitle: string) {
        this.titleService.setTitle(environment.applicationName + ' | ' + newTitle);
    }

    adminSignOut() {
        localStorage.removeItem(this.readOnlyValues.loggedIn.toString());
        this.appRouter.adminSignOut();
    }
}