import { NgModule } from '@angular/core';
import { NewAccountComponent } from './new-account.component';
import { NewAccountRoutingModule } from './new-account-routing.module';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthProvider } from '../auth-provider';

@NgModule({
    imports: [
        NewAccountRoutingModule,
        NgZorroAntdModule,
        ReactiveFormsModule,
        CommonModule
    ],
    declarations: [NewAccountComponent],
    exports: [NewAccountComponent],
    providers:[AuthProvider]
})
export class NewAccountModule { }
