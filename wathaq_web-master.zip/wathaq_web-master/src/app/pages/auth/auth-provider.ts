import { Injectable } from '@angular/core';
import { LoadingProvider } from 'src/app/providers/loading-provider';
import { HttpServicesProvider } from 'src/app/providers/http-services/http-services-provider';
import { DataService } from 'src/app/providers/data-service';
import { AppRouter } from 'src/app/providers/app-router';
import { NotificationService } from 'src/app/providers/notification-service';
import { ReadOnlyValues } from 'src/app/providers/readonly-values';

@Injectable()
export class AuthProvider {

    constructor(
        private loadingProvider: LoadingProvider,
        private httpServicesProvider: HttpServicesProvider,
        private dataService: DataService,
        private appRouter: AppRouter,
        private notificationService: NotificationService,
        private readOnlyValues: ReadOnlyValues
    ) { }

    signIn(data: any) {
        this.StartServiceLoading();
        this.httpServicesProvider.signIn(data.userName, data.password).subscribe(
            data => {
                this.StopServiceLoading();
                console.log(data);
                if (data.body.success === true) {
                    this.appRouter.goToAdminHome();
                    localStorage.setItem(this.readOnlyValues.loggedIn.toString(), data.body.success);
                } else {
                    this.notificationService.createErrorNotification('اسم المستخدم او كلمة السر خاطئة');
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    CreateCompany(obj: any) {
        this.StartServiceLoading();
        this.httpServicesProvider.createCompany(obj).subscribe(
            data => {
                this.StopServiceLoading();
                debugger;
                console.log(data, ' Data for create company');
                if (data.response === 'ok') {
                    // localStorage.setItem(this.readOnlyValues.loggedIn.toString(), data.body.success);
                    this.notificationService.createInfoNotification('تم انشاء الحساب بنجاح');
                    this.appRouter.goToLogIn();
                } else {
                    this.notificationService.createErrorNotification('اسم المستخدم او كلمة السر خاطئة');
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    StartServiceLoading() {
        this.loadingProvider.ViewHttpServiceLoading();
    }

    StopServiceLoading() {
        this.loadingProvider.CloseHttpServiceLoading();
    }

    HandleErrorCodeAndStopServiceLoading(ErrorMessage) {
        this.loadingProvider.CloseHttpServiceLoading();
        this.notificationService.createErrorNotification(ErrorMessage);
    }
}