import { NgModule } from '@angular/core';
import { SignInComponent } from './login.component';
import { SignInRoutingModule } from './login-routing.module';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthProvider } from '../auth-provider';

@NgModule({
    imports: [
        SignInRoutingModule,
        NgZorroAntdModule,
        ReactiveFormsModule,
        CommonModule
    ],
    declarations: [SignInComponent],
    exports: [SignInComponent],
    providers:[AuthProvider]
})
export class SignInModule { }
