import { Injectable } from '@angular/core';
import { LoadingProvider } from 'src/app/providers/loading-provider';
import { HttpServicesProvider } from 'src/app/providers/http-services/http-services-provider';
import { DataService } from 'src/app/providers/data-service';
import { NotificationService } from 'src/app/providers/notification-service';
import { AppRouter } from 'src/app/providers/app-router';

@Injectable()
export class WelcomeProvider {

    startNowLoading: boolean = false;

    constructor(
        private loadingProvider: LoadingProvider,
        private httpServicesProvider: HttpServicesProvider,
        public dataService: DataService,
        private notificationService: NotificationService,
        private appRouter: AppRouter
    ) { }

    StartServiceLoading() {
        this.loadingProvider.ViewHttpServiceLoading();
    }

    StopServiceLoading() {
        this.loadingProvider.CloseHttpServiceLoading();
    }

    HandleErrorCodeAndStopServiceLoading(ErrorMessage) {
        this.loadingProvider.CloseHttpServiceLoading();
        this.notificationService.createErrorNotification(ErrorMessage);
    }
}