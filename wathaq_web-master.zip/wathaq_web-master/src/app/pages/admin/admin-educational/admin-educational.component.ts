import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-educational',
  templateUrl: './admin-educational.component.html',
  styleUrls: ['./admin-educational.component.scss']
})
export class AdminEducationalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
