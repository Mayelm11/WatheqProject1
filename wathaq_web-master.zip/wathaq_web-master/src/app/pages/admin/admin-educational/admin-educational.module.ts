import { NgModule } from '@angular/core';
import { AdminEducationalComponent } from './admin-educational.component';
import { AdminEducationalRoutingModule } from './admin-educational-routing.module';

@NgModule({
  declarations: [AdminEducationalComponent],
  imports: [AdminEducationalRoutingModule],
  exports: [AdminEducationalComponent]
})
export class AdminEducationalModule { }
