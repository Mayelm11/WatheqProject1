import { NgModule } from '@angular/core';
import { AdminCompaniesComponent } from './admin-companies.component';
import { AdminCompaniesRoutingModule } from './admin-companies-routing.module';

@NgModule({
  declarations: [AdminCompaniesComponent],
  imports: [AdminCompaniesRoutingModule],
  exports: [AdminCompaniesComponent]
})
export class AdminCompaniesModule { }
