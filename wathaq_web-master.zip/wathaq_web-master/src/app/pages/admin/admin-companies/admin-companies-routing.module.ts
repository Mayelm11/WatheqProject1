import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminCompaniesComponent } from './admin-companies.component';

const routes: Routes = [
  {
    path: '', component: AdminCompaniesComponent, data: {
      heading: 'الشركات'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminCompaniesRoutingModule { }
