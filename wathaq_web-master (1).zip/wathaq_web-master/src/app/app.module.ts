import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IconsProviderModule } from './icons-provider.module';
import { NgZorroAntdModule, NZ_I18N, en_US } from 'ng-zorro-antd';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { registerLocaleData } from '@angular/common';
import { OuterLayoutComponent } from './layouts/outer-layout/outer-layout.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { AppRouter } from './providers/app-router';
import en from '@angular/common/locales/en';
import { DataService } from './providers/data-service';
import { HttpServicesProvider } from './providers/http-services/http-services-provider';
import { HttpHeaderProvider } from './providers/http-services/http-header-provider';
import { LoadingProvider } from './providers/loading-provider';
import { ReadOnlyValues } from './providers/readonly-values';
import { NotificationService } from './providers/notification-service';
import { DateProvider } from './providers/date-provider';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

registerLocaleData(en);

@NgModule({
  declarations: [
    AppComponent,
    OuterLayoutComponent,
    AdminLayoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    IconsProviderModule,
    NgZorroAntdModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule
  ],
  providers: [{ provide: NZ_I18N, useValue: en_US }, Title,
    AppRouter, DataService, HttpHeaderProvider, HttpServicesProvider, LoadingProvider, ReadOnlyValues, NotificationService, DateProvider],
  bootstrap: [AppComponent]
})
export class AppModule { }
