import { NgModule } from '@angular/core';
import { AdminLanguageComponent } from './admin-language.component';
import { AdminLanguageRoutingModule } from './admin-language-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { CommonModule } from '@angular/common';
import { AdminProvider } from '../admin-provider';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [AdminLanguageRoutingModule, ReactiveFormsModule, NgZorroAntdModule, CommonModule, FormsModule, NgbDatepickerModule],
  declarations: [AdminLanguageComponent],
  exports: [AdminLanguageComponent],
  providers: [AdminProvider]
})
export class AdminCompaniesModule { }
