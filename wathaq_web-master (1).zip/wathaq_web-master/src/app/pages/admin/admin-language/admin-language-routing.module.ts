import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminLanguageComponent } from './admin-language.component';

const routes: Routes = [
  {
    path: '', component: AdminLanguageComponent, data: {
      heading: 'الشركات'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminLanguageRoutingModule { }
