import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppRouter } from 'src/app/providers/app-router';
import { NzModalService, NzI18nService, ar_EG } from 'ng-zorro-antd';
import { DateProvider } from 'src/app/providers/date-provider';
import { AdminProvider } from '../admin-provider';
import { ReadOnlyValues } from 'src/app/providers/readonly-values';

@Component({
  selector: 'app-admin-language',
  templateUrl: './admin-language.component.html',
  styleUrls: ['./admin-language.component.scss']
})
export class AdminLanguageComponent implements OnInit {

  addLanguageForm: FormGroup;
  projectId: Number;
  type: string;

  constructor(
    public appRouter: AppRouter,
    private modalService: NzModalService,
    public dateProvider: DateProvider,
    private fb: FormBuilder,
    public adminProvider: AdminProvider,
    private readOnlyValues: ReadOnlyValues,
    private i18n: NzI18nService
  ) { }

  ngOnInit() {
    this.applyAddLanguageForm();
    this.adminProvider.filterLanguage();
  }

  addLanguage() {
    console.log(this.addLanguageForm.value);
    this.adminProvider.addLanguage(this.addLanguageForm.value);
    this.applyAddLanguageForm();
  }

  applyAddLanguageForm() {
    this.addLanguageForm = this.fb.group({
      indID: [localStorage.getItem(this.readOnlyValues.loggedInId), []],
      langugeName: [null, [Validators.required]],
      addBy: [null, [Validators.required]],
      langugeDate: [, [Validators.required]],
      langugeRefrenceNo: [, [Validators.required]]
    });
  }

  uploadeLanguagePDF(event: any) {
    if (event.target.files && event.target.files[0]) {
      this.adminProvider.PDFFile = event.target.files[0];
    }
  }

  createLanguageTplModal(tplTitle: TemplateRef<{}>, tplContent: TemplateRef<{}>, tplFooter: TemplateRef<{}>): void {
    if (this.addLanguageForm.value.environmentId !== null) {
      this.applyAddLanguageForm();
    }
    this.adminProvider.commonTplModal = this.modalService.create({
      nzTitle: tplTitle,
      nzContent: tplContent,
      nzFooter: tplFooter,
      nzMaskClosable: true,
      nzClosable: true,
    });
  }
}
