import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminEducationalComponent } from './admin-educational.component';

const routes: Routes = [
  {
    path: '', component: AdminEducationalComponent, data: {
      heading: 'التدريب'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminEducationalRoutingModule { }
