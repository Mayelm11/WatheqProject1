import { Injectable } from '@angular/core';
import { LoadingProvider } from 'src/app/providers/loading-provider';
import { HttpServicesProvider } from 'src/app/providers/http-services/http-services-provider';
import { DataService } from 'src/app/providers/data-service';
import { AppRouter } from 'src/app/providers/app-router';
import { NotificationService } from 'src/app/providers/notification-service';
import { ReadOnlyValues } from 'src/app/providers/readonly-values';
import { NzModalRef } from 'ng-zorro-antd';

@Injectable()
export class AdminProvider {

    commonTplModal: NzModalRef;
    environmentsData: any;
    envSpinnerShow = false;
    isOkLoading = false;
    confirmModal: NzModalRef;

    allIndividual: any;
    allCertificates: any;
    allLanguages: any;

    PDFFile;

    constructor(
        private loadingProvider: LoadingProvider,
        private httpServicesProvider: HttpServicesProvider,
        private dataService: DataService,
        private appRouter: AppRouter,
        private notificationService: NotificationService,
        private readOnlyValues: ReadOnlyValues
    ) { }

    getAllIndividuals() {
        this.httpServicesProvider.getAllIndividuals().subscribe(
            data => {
                this.allIndividual = data;
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    addCompanyCertificate(value: any) {
        this.isOkLoading = true;

        let objDate = value.joinDate;
        value.joinDate = objDate.year + "-" + objDate.month + "-" + objDate.day;

        let objDate1 = value.leaveDate;
        value.leaveDate = objDate1.year + "-" + objDate1.month + "-" + objDate1.day;

        this.httpServicesProvider.addCompanyCertificate(value).subscribe(
            data => {
                console.log(data.response);
                this.notificationService.createInfoNotification('تمت الاضافة بنجاح');
                this.uploadeCertificatePDF(data.id);
                this.filterCompCertificate();
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.isOkLoading = false;
            }
        );
    }

    addEduCertificate(value: any) {
        this.isOkLoading = true;
        this.httpServicesProvider.addEduCertificate(value).subscribe(
            data => {
                console.log(data.response);
                this.notificationService.createInfoNotification('تمت الاضافة بنجاح');
                this.uploadeCertificatePDF(data.id);
                this.filterEduCertificate();
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.isOkLoading = false;
            }
        );
    }

    filterCompCertificate() {
        this.envSpinnerShow = true;
        let compId = +localStorage.getItem(this.readOnlyValues.loggedInId);
        let typeStr = localStorage.getItem(this.readOnlyValues.loggedInType);
        this.httpServicesProvider.filterCompCertificate(compId, typeStr).subscribe(
            data => {
                console.log(data);
                this.allCertificates = data;
                this.envSpinnerShow = false;
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.envSpinnerShow = false;
            }
        );
    }

    filterEduCertificate() {
        this.envSpinnerShow = true;
        let compId = +localStorage.getItem(this.readOnlyValues.loggedInId);
        let typeStr = localStorage.getItem(this.readOnlyValues.loggedInType);
        this.httpServicesProvider.filterEduCertificate(compId, typeStr).subscribe(
            data => {
                console.log(data);
                this.allCertificates = data;
                this.envSpinnerShow = false;
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.envSpinnerShow = false;
            }
        );
    }

    uploadeCertificatePDF(certificateId) {
        this.httpServicesProvider.uploadecertificatePDF(this.PDFFile, certificateId).subscribe(
            data => {
                if (data.type === 4) {
                    console.log('Upload done!');
                    this.notificationService.createInfoNotification('تم رفع الملف بنجاح');
                    this.isOkLoading = false;
                    this.commonTplModal.destroy();
                    this.PDFFile = undefined;
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.PDFFile = undefined;
            }
        );
    }

    addLanguage(value: any) {
        this.isOkLoading = true;

        let objDate = value.langugeDate;
        value.langugeDate = objDate.year + "-" + objDate.month + "-" + objDate.day;

        this.httpServicesProvider.addLanguage(value).subscribe(
            data => {
                console.log(data.response);
                this.notificationService.createInfoNotification('تمت الاضافة بنجاح');
                this.uploadeLanguagePDF(data.id);
                this.filterLanguage();
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.isOkLoading = false;
            }
        );
    }

    uploadeLanguagePDF(langId) {
        this.httpServicesProvider.uploadLanguagePDF(this.PDFFile, langId).subscribe(
            data => {
                if (data.type === 4) {
                    console.log('Upload done!');
                    this.notificationService.createInfoNotification('تم رفع الملف بنجاح');
                    this.isOkLoading = false;
                    this.commonTplModal.destroy();
                    this.PDFFile = undefined;
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.isOkLoading = false;
                this.commonTplModal.destroy();
                this.PDFFile = undefined;
            }
        );
    }

    filterLanguage() {
        this.envSpinnerShow = true;
        let compId = +localStorage.getItem(this.readOnlyValues.loggedInId);
        let typeStr = localStorage.getItem(this.readOnlyValues.loggedInType);
        this.httpServicesProvider.filterLanguage(compId).subscribe(
            data => {
                console.log(data);
                this.allLanguages = data;
                this.envSpinnerShow = false;
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
                this.envSpinnerShow = false;
            }
        );
    }

    download(certId) {
        this.httpServicesProvider.filterLanguage(certId).subscribe(
            data => {
                this.allLanguages = data;
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    StartServiceLoading() {
        this.loadingProvider.ViewHttpServiceLoading();
    }

    StopServiceLoading() {
        this.loadingProvider.CloseHttpServiceLoading();
    }

    HandleErrorCodeAndStopServiceLoading(ErrorMessage) {
        this.loadingProvider.CloseHttpServiceLoading();
        this.notificationService.createErrorNotification(ErrorMessage);
    }
}