import { NgModule } from '@angular/core';
import { AdminCompaniesComponent } from './admin-companies.component';
import { AdminCompaniesRoutingModule } from './admin-companies-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { CommonModule } from '@angular/common';
import { AdminProvider } from '../admin-provider';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [AdminCompaniesRoutingModule, ReactiveFormsModule, NgZorroAntdModule, CommonModule, FormsModule, NgbDatepickerModule],
  declarations: [AdminCompaniesComponent],
  exports: [AdminCompaniesComponent],
  providers: [AdminProvider]
})
export class AdminCompaniesModule { }
