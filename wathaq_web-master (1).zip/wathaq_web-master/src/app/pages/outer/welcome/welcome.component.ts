import { Component, OnInit } from '@angular/core';
import { WelcomeProvider } from './welcome-provider';
import { AppRouter } from 'src/app/providers/app-router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent implements OnInit {

  gettingStartForm: FormGroup;

  constructor(
    public welcomeProvider: WelcomeProvider,
    public appRouter: AppRouter,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
  }


}
