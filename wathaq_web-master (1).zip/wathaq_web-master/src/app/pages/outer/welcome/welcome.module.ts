import { NgModule } from '@angular/core';

import { WelcomeRoutingModule } from './welcome-routing.module';

import { WelcomeComponent } from './welcome.component';
import { ReactiveFormsModule, FormControl, FormsModule } from '@angular/forms';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { CommonModule } from '@angular/common';
import { WelcomeProvider } from './welcome-provider';


@NgModule({
  imports: [
    WelcomeRoutingModule,
    ReactiveFormsModule,
    NgZorroAntdModule,
    CommonModule,
    FormsModule
  ],
  declarations: [WelcomeComponent],
  exports: [WelcomeComponent],
  providers: [WelcomeProvider]
})
export class WelcomeModule { }
