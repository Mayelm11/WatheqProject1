import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppRouter } from 'src/app/providers/app-router';
import { AuthProvider } from '../auth-provider';
import { DataService } from 'src/app/providers/data-service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})

export class SignInComponent implements OnInit {

    validateForm: FormGroup;
    passwordFieldType = 'password';
    iconeye = 'eye';

    constructor(
        private fb: FormBuilder,
        public appRouter: AppRouter,
        private authProvider: AuthProvider,
        private dataService: DataService,
    ) { }

    ngOnInit(): void {
        this.validateForm = this.fb.group({
            userName: [null, [Validators.required]],
            password: [null, [Validators.required]],
        });
    }

    submitForm(): void {
        for (const i in this.validateForm.controls) {
            this.validateForm.controls[i].markAsDirty();
            this.validateForm.controls[i].updateValueAndValidity();
            this.validateForm.controls[i].clearValidators();
        }
        if (this, this.validateForm.valid) {
            this.authProvider.signIn(this.validateForm.value);
        }
    }

    showPassword() {
        if (this.passwordFieldType === 'password') {
            this.passwordFieldType = 'text';
            this.iconeye = 'eye-invisible';
        } else {
            this.passwordFieldType = 'password';
            this.iconeye = 'eye';
        }
    }
}
