import { HttpHeaderProvider } from './http-header-provider';
import { Injectable } from '@angular/core';
import { map, timeout } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable()
export class HttpServicesProvider {

  constructor(
    public http: HttpClient,
    private httpHeaderProvider: HttpHeaderProvider
  ) { }

  signIn(username: String, password: String): Observable<any> {
    return this.http.get<any>(environment.DOMAIN_URL + '/auth/login?username=' + username + "&password=" + password, { headers: this.httpHeaderProvider.getHeaderJson(), observe: 'response' })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  createCompany(obj: any): Observable<any> {
    return this.http.post(environment.DOMAIN_URL + '/company/insertCompany', obj, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  UploadecompanyPDF(PDF, companyidId): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', PDF);
    return this.http.post(environment.DOMAIN_URL + '/company/upload?companyid=' + companyidId, formData, {
      headers: this.httpHeaderProvider.getHeaderAcceptJson(), reportProgress: true, observe: 'events'
    })
      .pipe(map(Response => {
        return Response;
      }));
  }

  createEducational(obj: any): Observable<any> {
    return this.http.post(environment.DOMAIN_URL + '/education/insertEdu', obj, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  UploadeEduPDF(PDF, eduId): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', PDF);
    return this.http.post(environment.DOMAIN_URL + '/education/upload?eduid=' + eduId, formData, {
      headers: this.httpHeaderProvider.getHeaderAcceptJson(), reportProgress: true, observe: 'events'
    })
      .pipe(map(Response => {
        return Response;
      }));
  }

  createIndividual(obj: any): Observable<any> {
    return this.http.post(environment.DOMAIN_URL + '/individual/insertIndividual', obj, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  getAllIndividuals(): Observable<any> {
    return this.http.get(environment.DOMAIN_URL + '/individual/filter', { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  addCompanyCertificate(obj: any): Observable<any> {
    return this.http.post(environment.DOMAIN_URL + '/certificate/insertCompanyCertificate', obj, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  addEduCertificate(obj: any): Observable<any> {
    return this.http.post(environment.DOMAIN_URL + '/certificate/insertEduCertificate', obj, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  filterCompCertificate(compId: Number, typeStr: string): Observable<any> {
    return this.http.get(environment.DOMAIN_URL + '/certificate/filtercompany?compid=' + compId + "&type=" + typeStr, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  filterEduCertificate(compId: Number, typeStr: string): Observable<any> {
    return this.http.get(environment.DOMAIN_URL + '/certificate/filteredu?compid=' + compId + "&type=" + typeStr, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  uploadecertificatePDF(PDF, certificateId): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', PDF);
    return this.http.post(environment.DOMAIN_URL + '/certificate/upload?certificateid=' + certificateId, formData, {
      headers: this.httpHeaderProvider.getHeaderAcceptJson(), reportProgress: true, observe: 'events'
    })
      .pipe(map(Response => {
        return Response;
      }));
  }

  addLanguage(obj: any): Observable<any> {
    return this.http.post(environment.DOMAIN_URL + '/language/insertlanguage', obj, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }

  uploadLanguagePDF(PDF, companyidId): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', PDF);
    return this.http.post(environment.DOMAIN_URL + '/language/upload?langid=' + companyidId, formData, {
      headers: this.httpHeaderProvider.getHeaderAcceptJson(), reportProgress: true, observe: 'events'
    })
      .pipe(map(Response => {
        return Response;
      }));
  }

  filterLanguage(indId: Number): Observable<any> {
    return this.http.get(environment.DOMAIN_URL + '/language/filter?indid=' + indId, { headers: this.httpHeaderProvider.getHeaderJson() })
      .pipe(timeout(environment.ApplicationHttpServiceTimeout), map(Response => {
        return Response;
      }));
  }
}
