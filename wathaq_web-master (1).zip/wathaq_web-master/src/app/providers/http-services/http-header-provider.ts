import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { DataService } from '../data-service';

@Injectable()
export class HttpHeaderProvider {

    constructor(public data: DataService) { }

    getHeaderJson() {
        const contentHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        });
        return contentHeaders;
    }

    getHeaderAcceptJson() {
        const contentHeaders = new HttpHeaders({
            'Accept': 'application/json'
        });
        return contentHeaders;
    }

    getHeaderXWFORM() {
        const contentHeaders = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        return contentHeaders;
    }

    getHeaderXWFORM2() {
        const contentHeaders = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded'
        });
        return contentHeaders;
    }
}
