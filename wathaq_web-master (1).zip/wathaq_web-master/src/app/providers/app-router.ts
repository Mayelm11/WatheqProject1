import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ReadOnlyValues } from './readonly-values';
import { DataService } from './data-service';

@Injectable()
export class AppRouter {

    constructor(
        private router: Router,
        private readOnlyValues: ReadOnlyValues,
        private dataService: DataService
    ) { }

    goToHome() {
        this.router.navigate([this.readOnlyValues.welcomePage]);
    }

    goToLogIn() {
        this.router.navigate([this.readOnlyValues.loginPage]);
    }

    goToNewAccount() {
        this.router.navigate([this.readOnlyValues.newAccount]);
    }

    goToAdminHome(typeStr: string) {
        if (typeStr === 'ind') {
            this.adminGoToIndividual();
        } else if (typeStr === 'comp') {
            this.adminGoToCompanies();
        } else if (typeStr === 'edu') {
            this.adminGoToEducational();
        }
    }

    adminSignOut() {
        this.router.navigate([this.readOnlyValues.welcomePage]);
    }

    adminGoToCompanies() {
        this.router.navigate([this.readOnlyValues.companies]);
    }

    adminGoToEducational() {
        this.router.navigate([this.readOnlyValues.educational]);
    }

    adminGoToIndividual() {
        this.router.navigate([this.readOnlyValues.individual]);
    }

    adminGoToIndividualLangu() {
        this.router.navigate([this.readOnlyValues.individualLang]);
    }
}