import { Injectable } from '@angular/core';

@Injectable()
export class DateProvider {

    constructor(
    ) { }

    SubtractTwoDatesFromNow(SubtractDate: any): string {
        let Now: any = new Date();
        let OldDate: any = new Date(SubtractDate);
        let DifferenceBetweenDates: any = (Now - OldDate);
        let DifferenceBetweenDatesWithYears: any = Math.floor(DifferenceBetweenDates / 31557600000);
        let DifferenceBetweenDatesWithMonths: any = Math.floor(DifferenceBetweenDates / 2628000000);
        let DifferenceBetweenDatesWithWeeks: any = Math.floor(DifferenceBetweenDates / 604800000);
        let DifferenceBetweenDatesWithDays: any = Math.floor(DifferenceBetweenDates / 86400000);
        let DifferenceBetweenDatesWithHours: any = Math.floor((DifferenceBetweenDates % 86400000) / 3600000);
        let DifferenceBetweenDatesWithMinutes: any = Math.round(((DifferenceBetweenDates % 86400000) % 3600000) / 60000);
        let ReturnedValue: string;
        // let Language = this.appVariables.GetLanguage();
        ////////////////////////////////////////     Minutes      /////////////////////////////////////////
        if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0 && DifferenceBetweenDatesWithWeeks === 0 && DifferenceBetweenDatesWithDays === 0 && DifferenceBetweenDatesWithHours === 0) {
            if (DifferenceBetweenDatesWithMinutes < 15) {
                ReturnedValue = 'Now';
            } else if (DifferenceBetweenDatesWithMinutes < 30) {
                ReturnedValue = '15 Minutes ago';
            } else if (DifferenceBetweenDatesWithMinutes < 60) {
                ReturnedValue = '30 Minutes ago';
            }
            ////////////////////////////////////////     Hours      /////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0 && DifferenceBetweenDatesWithWeeks === 0 && DifferenceBetweenDatesWithDays === 0) {
            if (DifferenceBetweenDatesWithHours === 1) {
                ReturnedValue = 'Hour ago';
            } else if (DifferenceBetweenDatesWithHours === 2) {
                ReturnedValue = '2 Hours ago';
            } else if (DifferenceBetweenDatesWithHours <= 10) {
                ReturnedValue = DifferenceBetweenDatesWithHours + ' Hours ago';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithHours + ' Hours ago';
            }
            ////////////////////////////////////////     Days      //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0 && DifferenceBetweenDatesWithWeeks === 0) {
            if (DifferenceBetweenDatesWithDays === 1) {
                ReturnedValue = 'Day ago';
            } else if (DifferenceBetweenDatesWithDays === 2) {
                ReturnedValue = '2 Days ago';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithDays + ' Days ago';
            }
            ////////////////////////////////////////     Weeks     //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0) {
            if (DifferenceBetweenDatesWithWeeks === 1) {
                ReturnedValue = 'Week ago';
            } else if (DifferenceBetweenDatesWithWeeks === 2) {
                ReturnedValue = '2 Weeks ago';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithWeeks + ' Weeks ago';
            }
            ////////////////////////////////////////     Months     //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0) {
            if (DifferenceBetweenDatesWithMonths === 1) {
                ReturnedValue = 'Month ago';
            } else if (DifferenceBetweenDatesWithMonths === 2) {
                ReturnedValue = '2 Months ago';
            } else if (DifferenceBetweenDatesWithMonths <= 10) {
                ReturnedValue = DifferenceBetweenDatesWithMonths + ' Months ago';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithMonths + ' Months ago';
            }
            ////////////////////////////////////////     Years     //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears >= 1) {
            if (DifferenceBetweenDatesWithYears === 1) {
                ReturnedValue = 'Year ago';
            } else if (DifferenceBetweenDatesWithYears === 2) {
                ReturnedValue = '2 Years ago';
            } else if (DifferenceBetweenDatesWithYears <= 10) {
                ReturnedValue = DifferenceBetweenDatesWithYears + ' Years ago';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithYears + ' Years ago';
            }
        }
        return ReturnedValue;
    }

    subtractFutureDatesFromNow(SubtractDate: any): string {
        let Now: any = new Date(SubtractDate);
        let OldDate: any = new Date();
        let DifferenceBetweenDates: any = (Now - OldDate);
        let DifferenceBetweenDatesWithYears: any = Math.floor(DifferenceBetweenDates / 31557600000);
        let DifferenceBetweenDatesWithMonths: any = Math.floor(DifferenceBetweenDates / 2628000000);
        let DifferenceBetweenDatesWithWeeks: any = Math.floor(DifferenceBetweenDates / 604800000);
        let DifferenceBetweenDatesWithDays: any = Math.floor(DifferenceBetweenDates / 86400000);
        let DifferenceBetweenDatesWithHours: any = Math.floor((DifferenceBetweenDates % 86400000) / 3600000);
        let DifferenceBetweenDatesWithMinutes: any = Math.round(((DifferenceBetweenDates % 86400000) % 3600000) / 60000);
        let ReturnedValue: string = 'Old Date';
        // let Language = this.appVariables.GetLanguage();
        ////////////////////////////////////////     Minutes      /////////////////////////////////////////
        if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0 && DifferenceBetweenDatesWithWeeks === 0 && DifferenceBetweenDatesWithDays === 0 && DifferenceBetweenDatesWithHours === 0) {
            if (DifferenceBetweenDatesWithMinutes < 15) {
                ReturnedValue = 'Today';
            } else if (DifferenceBetweenDatesWithMinutes < 30) {
                ReturnedValue = '15 Minutes remining';
            } else if (DifferenceBetweenDatesWithMinutes < 60) {
                ReturnedValue = '30 Minutes remining';
            }
            ////////////////////////////////////////     Hours      /////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0 && DifferenceBetweenDatesWithWeeks === 0 && DifferenceBetweenDatesWithDays === 0) {
            if (DifferenceBetweenDatesWithHours === 1) {
                ReturnedValue = 'Hour remining';
            } else if (DifferenceBetweenDatesWithHours === 2) {
                ReturnedValue = '2 Hours remining';
            } else if (DifferenceBetweenDatesWithHours <= 10) {
                ReturnedValue = DifferenceBetweenDatesWithHours + ' Hours remining';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithHours + ' Hours remining';
            }
            ////////////////////////////////////////     Days      //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0 && DifferenceBetweenDatesWithWeeks === 0) {
            if (DifferenceBetweenDatesWithDays === 1) {
                ReturnedValue = 'Day remining';
            } else if (DifferenceBetweenDatesWithDays === 2) {
                ReturnedValue = '2 Days remining';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithDays + ' Days remining';
            }
            ////////////////////////////////////////     Weeks     //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0 && DifferenceBetweenDatesWithMonths === 0) {
            if (DifferenceBetweenDatesWithWeeks === 1) {
                ReturnedValue = 'Week remining';
            } else if (DifferenceBetweenDatesWithWeeks === 2) {
                ReturnedValue = '2 Weeks remining';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithWeeks + ' Weeks remining';
            }
            ////////////////////////////////////////     Months     //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears === 0) {
            if (DifferenceBetweenDatesWithMonths === 1) {
                ReturnedValue = 'Month remining';
            } else if (DifferenceBetweenDatesWithMonths === 2) {
                ReturnedValue = '2 Months remining';
            } else if (DifferenceBetweenDatesWithMonths <= 10) {
                ReturnedValue = DifferenceBetweenDatesWithMonths + ' Months remining';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithMonths + ' Months remining';
            }
            ////////////////////////////////////////     Years     //////////////////////////////////////////
        } else if (DifferenceBetweenDatesWithYears >= 1) {
            if (DifferenceBetweenDatesWithYears === 1) {
                ReturnedValue = 'Year remining';
            } else if (DifferenceBetweenDatesWithYears === 2) {
                ReturnedValue = '2 Years remining';
            } else if (DifferenceBetweenDatesWithYears <= 10) {
                ReturnedValue = DifferenceBetweenDatesWithYears + ' Years remining';
            } else {
                ReturnedValue = DifferenceBetweenDatesWithYears + ' Years remining';
            }
        }
        return ReturnedValue;
    }

    AddNumberFromNowToReturnDate(SubtractNumber: number): any {
        const Now: Date = new Date();
        Now.setDate(Now.getDate() + SubtractNumber);
        const NewDate = Now.toISOString().substring(0, 10)
        let ReturnedValue: any;
        ReturnedValue = NewDate;
        return ReturnedValue;
    }
}
