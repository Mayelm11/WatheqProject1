import { Injectable, TemplateRef } from "@angular/core";
import { NzNotificationService } from 'ng-zorro-antd';
import { environment } from 'src/environments/environment';

@Injectable()
export class NotificationService {

    readonly successType = 'success';
    readonly infoType = 'info';
    readonly warningType = 'warning';
    readonly errorType = 'error';

    constructor(
        private notification: NzNotificationService
    ) { }

    createSuccessNotification(message: string) {
        this.notification.create(this.successType, environment.applicationName, message);
    }

    createInfoNotification(message: string) {
        this.notification.create(this.infoType, environment.applicationName, message);
    }

    createWarningNotification(message: string) {
        this.notification.create(this.warningType, environment.applicationName, message);
    }

    createErrorNotification(message: string) {
        this.notification.create(this.errorType, environment.applicationName, message);
    }
}