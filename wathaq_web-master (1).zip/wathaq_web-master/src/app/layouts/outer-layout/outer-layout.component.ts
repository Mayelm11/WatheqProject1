import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';
import { AppRouter } from 'src/app/providers/app-router';

@Component({
    selector: 'outer-layout',
    templateUrl: './outer-layout.component.html',
    styleUrls: ['./outer-layout.component.scss']
})

export class OuterLayoutComponent {

    constructor(
        private titleService: Title,
        public appRouter: AppRouter
    ) {
        titleService.setTitle(environment.title);
    }
}