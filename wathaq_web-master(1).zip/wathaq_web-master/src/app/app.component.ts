import { Component } from '@angular/core';
import { LoadingProvider } from './providers/loading-provider';
import { DataService } from './providers/data-service';
import { AppRouter } from './providers/app-router';
import { Router } from '@angular/router';
import { ReadOnlyValues } from './providers/readonly-values';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})

export class AppComponent {

  constructor(
    private loadingProvider: LoadingProvider,
    private dataService: DataService,
    private appRouter: AppRouter,
    private readOnlyValues: ReadOnlyValues
  ) {
    this.loadingProvider.StopFirstLoading();
    this.checkRoutingPehaviour();
  }

  checkRoutingPehaviour() {
    console.log(window.location.pathname, ' pathname');
    if (window.location.pathname === "" || window.location.pathname === "/" || window.location.pathname === "/Wathaq_web/") {
      if (localStorage.getItem(this.readOnlyValues.loggedIn) === "true") {
        let typeStr = localStorage.getItem(this.readOnlyValues.loggedInType);
        this.appRouter.goToAdminHome(typeStr);
      } else {
        this.appRouter.goToHome();
      }
    }
  }
}
