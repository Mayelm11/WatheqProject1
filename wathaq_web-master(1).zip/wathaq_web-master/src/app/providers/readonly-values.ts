
export class ReadOnlyValues {

    readonly welcomePage: String = "welcome";
    readonly loginPage: String = "login";
    readonly newAccount: String = "newaccount";

    readonly companies: String = "/admin/companies";
    readonly educational: String = "/admin/educational";
    readonly individual: String = "/admin/individual";
    readonly individualLang: String = "/admin/individual-language";

    readonly loggedIn: string = "logged-in";
    readonly loggedInId: string = "logged-in-id";
    readonly loggedInType: string = "logged-in-type";
}