import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OuterLayoutComponent } from './layouts/outer-layout/outer-layout.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';

const routes: Routes = [
  // {
  //   path: '',
  //   pathMatch: 'full',
  //   redirectTo: '/login'
  // },
  { // Outer Layout
    path: '',
    component: OuterLayoutComponent,
    children: [
      {
        path: 'welcome',
        loadChildren: () => import('./pages/outer/welcome/welcome.module').then(m => m.WelcomeModule)
      }, {
        path: 'login',
        loadChildren: () => import('./pages/auth/login/login.module').then(m => m.SignInModule)
      }, {
        path: 'newaccount',
        loadChildren: () => import('./pages/auth/new-account/new-account.module').then(m => m.NewAccountModule)
      }
    ]
  },
  { // Admin Layout
    path: 'admin',
    component: AdminLayoutComponent,
    children: [
      {
        path: 'companies',
        loadChildren: () => import('./pages/admin/admin-companies/admin-companies.module').then(m => m.AdminCompaniesModule)
      }, {
        path: 'educational',
        loadChildren: () => import('./pages/admin/admin-educational/admin-educational.module').then(m => m.AdminEducationalModule)
      }, {
        path: 'individual',
        loadChildren: () => import('./pages/admin/admin-individual/admin-individual.module').then(m => m.AdminIndividualModule)
      }, {
        path: 'individual-language',
        loadChildren: () => import('./pages/admin/admin-language/admin-language.module').then(m => m.AdminCompaniesModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
