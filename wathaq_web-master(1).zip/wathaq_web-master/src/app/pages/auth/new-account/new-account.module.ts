import { NgModule } from '@angular/core';
import { NewAccountComponent } from './new-account.component';
import { NewAccountRoutingModule } from './new-account-routing.module';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthProvider } from '../auth-provider';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
    imports: [
        NewAccountRoutingModule,
        NgZorroAntdModule,
        ReactiveFormsModule,
        FormsModule,
        NgbDatepickerModule,
        CommonModule
    ],
    declarations: [NewAccountComponent],
    exports: [NewAccountComponent],
    providers: [AuthProvider]
})
export class NewAccountModule { }
