import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppRouter } from 'src/app/providers/app-router';
import { AuthProvider } from '../auth-provider';
import { DataService } from 'src/app/providers/data-service';
import { NgbDateStruct, NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-newaccount',
    templateUrl: './new-account.component.html',
    styleUrls: ['./new-account.component.scss']
})

export class NewAccountComponent implements OnInit {

    companyForm: FormGroup;
    educationalForm: FormGroup;
    individualForm: FormGroup;
    passwordFieldType = 'password';
    iconeye = 'eye';

    showCreateIndividualAccount = true;
    showCreateEducationalAccount = false;
    showCreateCompanyAccount = false;

    constructor(
        private fb: FormBuilder,
        public appRouter: AppRouter,
        private authProvider: AuthProvider,
        private dataService: DataService,
    ) { }

    ngOnInit(): void {
        this.applyCompanyForm();
        this.applyEducationalForm();
        this.applyIndividualForm();
    }

    applyCompanyForm() {
        this.companyForm = this.fb.group({
            // userName: [null, [Validators.required]],
            email: [null, [Validators.required, Validators.email]],
            password: [null, [Validators.required]],
            phoneNumber: [null, []],
            address: [null, []],
            companyName: [null, [Validators.required]]
        });
    }

    applyEducationalForm() {
        this.educationalForm = this.fb.group({
            // userName: [null, [Validators.required]],
            email: [null, [Validators.required, Validators.email]],
            password: [null, [Validators.required]],
            phoneNumber: [null, []],
            address: [null, []]
        });
    }

    applyIndividualForm() {
        this.individualForm = this.fb.group({
            nationalID: [null, [Validators.required]],
            // userName: [null, [Validators.required]],
            email: [null, [Validators.required, Validators.email]],
            password: [null, [Validators.required]],
            phoneNumber: [null, []],
            firstName: [null, [Validators.required]],
            middleName: [null, [Validators.required]],
            lastName: [null, [Validators.required]],
            address: [null, []],
            gender: [null, []],
            dateOfBirth: [null, [Validators.required]],
            skills: [null, []]
        });
    }

    showCreateIndividual() {
        this.showCreateIndividualAccount = true;
        this.showCreateCompanyAccount = false;
        this.showCreateEducationalAccount = false;
    }

    showCreateEducational() {
        this.showCreateEducationalAccount = true;
        this.showCreateIndividualAccount = false;
        this.showCreateCompanyAccount = false;
    }

    showCreateCompany() {
        this.showCreateCompanyAccount = true;
        this.showCreateEducationalAccount = false;
        this.showCreateIndividualAccount = false;
    }

    createCompany(): void {
        for (const i in this.companyForm.controls) {
            this.companyForm.controls[i].markAsDirty();
            this.companyForm.controls[i].updateValueAndValidity();
            this.companyForm.controls[i].clearValidators();
        }
        if (this, this.companyForm.valid) {
            this.authProvider.CreateCompany(this.companyForm.value);
        }
    }

    createEducational(): void {
        for (const i in this.educationalForm.controls) {
            this.educationalForm.controls[i].markAsDirty();
            this.educationalForm.controls[i].updateValueAndValidity();
            this.educationalForm.controls[i].clearValidators();
        }
        if (this, this.educationalForm.valid) {
            this.authProvider.CreateEdu(this.educationalForm.value);
        }
    }

    createIndividual(): void {
        for (const i in this.individualForm.controls) {
            this.individualForm.controls[i].markAsDirty();
            this.individualForm.controls[i].updateValueAndValidity();
            this.individualForm.controls[i].clearValidators();
        }
        if (this, this.individualForm.valid) {
            this.authProvider.CreateIndividual(this.individualForm.value);
        }
    }

    showPassword() {
        if (this.passwordFieldType === 'password') {
            this.passwordFieldType = 'text';
            this.iconeye = 'eye-invisible';
        } else {
            this.passwordFieldType = 'password';
            this.iconeye = 'eye';
        }
    }

    uploadeCompanyPDF(event: any) {
        if (event.target.files && event.target.files[0]) {
            this.authProvider.PDFFile = event.target.files[0];
            // this.authProvider.uploadeCompanyPDF(ImageFile, 1);
        }
    }

    uploadeEducationalPDF(event: any) {
        if (event.target.files && event.target.files[0]) {
            this.authProvider.PDFFile = event.target.files[0];
            // this.authProvider.uploadeCompanyPDF(ImageFile, 1);
        }
    }
}
