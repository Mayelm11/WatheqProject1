import { Injectable } from '@angular/core';
import { LoadingProvider } from 'src/app/providers/loading-provider';
import { HttpServicesProvider } from 'src/app/providers/http-services/http-services-provider';
import { DataService } from 'src/app/providers/data-service';
import { AppRouter } from 'src/app/providers/app-router';
import { NotificationService } from 'src/app/providers/notification-service';
import { ReadOnlyValues } from 'src/app/providers/readonly-values';

@Injectable()
export class AuthProvider {

    PDFFile;

    constructor(
        private loadingProvider: LoadingProvider,
        private httpServicesProvider: HttpServicesProvider,
        private dataService: DataService,
        private appRouter: AppRouter,
        private notificationService: NotificationService,
        private readOnlyValues: ReadOnlyValues
    ) { }

    signIn(data: any) {
        this.StartServiceLoading();
        this.httpServicesProvider.signIn(data.userName, data.password).subscribe(
            data => {
                this.StopServiceLoading();
                console.log(data);
                if (data.body.success === true) {
                    this.appRouter.goToAdminHome(data.body.type);
                    localStorage.setItem(this.readOnlyValues.loggedIn, data.body.success);
                    localStorage.setItem(this.readOnlyValues.loggedInId, data.body.id);
                    localStorage.setItem(this.readOnlyValues.loggedInType, data.body.type);
                } else {
                    this.notificationService.createErrorNotification('اسم المستخدم او كلمة السر خاطئة');
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    CreateCompany(obj: any) {
        this.StartServiceLoading();
        this.httpServicesProvider.createCompany(obj).subscribe(
            data => {
                this.StopServiceLoading();
                if (data.response === 'ok') {
                    this.notificationService.createInfoNotification('تم انشاء الحساب بنجاح');
                    this.uploadeCompanyPDF(data.id);
                } else if (data.response === 'error') {
                    this.notificationService.createErrorNotification('حساب موجود بالفعل');
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    CreateEdu(obj: any) {
        this.StartServiceLoading();
        this.httpServicesProvider.createEducational(obj).subscribe(
            data => {
                this.StopServiceLoading();
                if (data.response === 'ok') {
                    this.notificationService.createInfoNotification('تم انشاء الحساب بنجاح');
                    this.uploadeEducationalPDF(data.id);
                } else if (data.response === 'error') {
                    this.notificationService.createErrorNotification('حساب موجود بالفعل');
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    CreateIndividual(obj: any) {
        this.StartServiceLoading();
        let objDate = obj.dateOfBirth;
        obj.dateOfBirth = objDate.year + "-" + objDate.month + "-" + objDate.day;
        console.log(objDate);
        this.httpServicesProvider.createIndividual(obj).subscribe(
            data => {
                this.StopServiceLoading();
                if (data.response === 'ok') {
                    this.notificationService.createInfoNotification('تم انشاء الحساب بنجاح');
                    this.appRouter.goToLogIn();
                } else if (data.response === 'error') {
                    this.notificationService.createErrorNotification('حساب موجود بالفعل');
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    uploadeCompanyPDF(companyId) {
        this.httpServicesProvider.UploadecompanyPDF(this.PDFFile, companyId).subscribe(
            data => {
                if (data.type === 4) {
                    console.log('Upload done!');
                    this.notificationService.createInfoNotification('تم رفع الملف بنجاح');
                    this.appRouter.goToLogIn();
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    uploadeEducationalPDF(eduId) {
        this.httpServicesProvider.UploadeEduPDF(this.PDFFile, eduId).subscribe(
            data => {
                if (data.type === 4) {
                    console.log('Upload done!');
                    this.notificationService.createInfoNotification('تم رفع الملف بنجاح');
                    this.appRouter.goToLogIn();
                }
            }, error => {
                this.HandleErrorCodeAndStopServiceLoading(error.error.message);
            }
        );
    }

    StartServiceLoading() {
        this.loadingProvider.ViewHttpServiceLoading();
    }

    StopServiceLoading() {
        this.loadingProvider.CloseHttpServiceLoading();
    }

    HandleErrorCodeAndStopServiceLoading(ErrorMessage) {
        this.loadingProvider.CloseHttpServiceLoading();
        this.notificationService.createErrorNotification(ErrorMessage);
    }
}