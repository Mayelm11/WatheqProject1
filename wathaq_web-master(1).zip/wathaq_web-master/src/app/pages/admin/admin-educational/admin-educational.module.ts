import { NgModule } from '@angular/core';
import { AdminEducationalComponent } from './admin-educational.component';
import { AdminEducationalRoutingModule } from './admin-educational-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { AdminProvider } from '../admin-provider';

@NgModule({
  declarations: [AdminEducationalComponent],
  imports: [AdminEducationalRoutingModule, ReactiveFormsModule, NgZorroAntdModule, CommonModule, FormsModule],
  exports: [AdminEducationalComponent],
  providers: [AdminProvider]
})
export class AdminEducationalModule { }
