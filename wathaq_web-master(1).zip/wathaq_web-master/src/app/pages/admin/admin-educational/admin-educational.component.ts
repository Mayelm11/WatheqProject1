import { Component, OnInit, TemplateRef } from '@angular/core';
import { AppRouter } from 'src/app/providers/app-router';
import { NzModalService } from 'ng-zorro-antd';
import { DateProvider } from 'src/app/providers/date-provider';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminProvider } from '../admin-provider';
import { ReadOnlyValues } from 'src/app/providers/readonly-values';

@Component({
  selector: 'app-admin-educational',
  templateUrl: './admin-educational.component.html',
  styleUrls: ['./admin-educational.component.scss']
})
export class AdminEducationalComponent implements OnInit {

  addCertificateForm: FormGroup;
  projectId: Number;
  type: string;

  constructor(
    public appRouter: AppRouter,
    private modalService: NzModalService,
    public dateProvider: DateProvider,
    private fb: FormBuilder,
    public adminProvider: AdminProvider,
    private readOnlyValues: ReadOnlyValues
  ) {
    this.type = localStorage.getItem(this.readOnlyValues.loggedInType);
    adminProvider.getAllIndividuals();
  }

  ngOnInit() {
    this.applyAddCertificateForm();
    this.adminProvider.filterEduCertificate();
  }

  addCertificate() {
    console.log(this.addCertificateForm.value);
    this.adminProvider.addEduCertificate(this.addCertificateForm.value);
    this.applyAddCertificateForm();
  }

  applyAddCertificateForm() {
    this.addCertificateForm = this.fb.group({
      certificateID: [null, []],
      id: [localStorage.getItem(this.readOnlyValues.loggedInId), []],
      individualId: [null, [Validators.required]],
      addBy: [null, [Validators.required]],
      major: [null, [Validators.required]],
      degree: [null, [Validators.required]],
      gpa: [null, [Validators.required]],
    });
  }

  uploadeCompanyPDF(event: any) {
    if (event.target.files && event.target.files[0]) {
      this.adminProvider.PDFFile = event.target.files[0];
    }
  }

  createCertificateTplModal(tplTitle: TemplateRef<{}>, tplContent: TemplateRef<{}>, tplFooter: TemplateRef<{}>): void {
    if (this.addCertificateForm.value.environmentId !== null) {
      this.applyAddCertificateForm();
    }
    this.adminProvider.commonTplModal = this.modalService.create({
      nzTitle: tplTitle,
      nzContent: tplContent,
      nzFooter: tplFooter,
      nzMaskClosable: true,
      nzClosable: true,
    });
  }
}
