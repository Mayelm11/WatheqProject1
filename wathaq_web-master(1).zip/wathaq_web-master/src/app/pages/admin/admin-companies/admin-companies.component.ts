import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppRouter } from 'src/app/providers/app-router';
import { NzModalService, NzI18nService, ar_EG } from 'ng-zorro-antd';
import { DateProvider } from 'src/app/providers/date-provider';
import { AdminProvider } from '../admin-provider';
import { ReadOnlyValues } from 'src/app/providers/readonly-values';

@Component({
  selector: 'app-admin-companies',
  templateUrl: './admin-companies.component.html',
  styleUrls: ['./admin-companies.component.scss']
})
export class AdminCompaniesComponent implements OnInit {

  addCertificateForm: FormGroup;
  projectId: Number;
  type: string;

  constructor(
    public appRouter: AppRouter,
    private modalService: NzModalService,
    public dateProvider: DateProvider,
    private fb: FormBuilder,
    public adminProvider: AdminProvider,
    private readOnlyValues: ReadOnlyValues,
    private i18n: NzI18nService
  ) {
    this.type = localStorage.getItem(this.readOnlyValues.loggedInType);
    adminProvider.getAllIndividuals();
    // this.i18n.setLocale(ar_EG);
  }

  ngOnInit() {
    this.applyAddCertificateForm();
    this.adminProvider.filterCompCertificate();
  }

  addCertificate() {
    console.log(this.addCertificateForm.value);
    this.adminProvider.addCompanyCertificate(this.addCertificateForm.value);
    this.applyAddCertificateForm();
  }

  applyAddCertificateForm() {
    this.addCertificateForm = this.fb.group({
      certificateID: [null, []],
      id: [localStorage.getItem(this.readOnlyValues.loggedInId), []],
      individualId: [null, [Validators.required]],
      addBy: [null, [Validators.required]],
      joinDate: [, [Validators.required]],
      leaveDate: [, [Validators.required]]
    });
  }

  uploadeCompanyPDF(event: any) {
    if (event.target.files && event.target.files[0]) {
      this.adminProvider.PDFFile = event.target.files[0];
    }
  }

  createCertificateTplModal(tplTitle: TemplateRef<{}>, tplContent: TemplateRef<{}>, tplFooter: TemplateRef<{}>): void {
    if (this.addCertificateForm.value.environmentId !== null) {
      this.applyAddCertificateForm();
    }
    this.adminProvider.commonTplModal = this.modalService.create({
      nzTitle: tplTitle,
      nzContent: tplContent,
      nzFooter: tplFooter,
      nzMaskClosable: true,
      nzClosable: true,
    });
  }
}
