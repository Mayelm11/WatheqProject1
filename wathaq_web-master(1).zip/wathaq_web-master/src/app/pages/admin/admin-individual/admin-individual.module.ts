import { NgModule } from '@angular/core';
import { AdminIndividualComponent } from './admin-individual.component';
import { AdminIndividualRoutingModule } from './admin-individual-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { CommonModule } from '@angular/common';
import { AdminProvider } from '../admin-provider';

@NgModule({
  imports: [AdminIndividualRoutingModule, ReactiveFormsModule, NgZorroAntdModule, CommonModule, FormsModule],
  declarations: [AdminIndividualComponent],
  exports: [AdminIndividualComponent],
  providers: [AdminProvider]
})
export class AdminIndividualModule { }
