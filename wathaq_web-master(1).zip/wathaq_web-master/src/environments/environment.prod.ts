export const environment = {
  production: true,
  title: 'Wathaq',
  applicationName: 'Wathaq',
  backendAppName: 'WathaqWeb',
  DOMAIN_URL: 'http://localhost:8080/Wathaq_services',
  ApplicationHttpServiceTimeout: 40000
};
