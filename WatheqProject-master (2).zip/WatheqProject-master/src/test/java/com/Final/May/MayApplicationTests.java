package com.Final.May;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MayApplicationTests {

	@Test
	void contextLoads() {
	}

}
