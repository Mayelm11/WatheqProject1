package com.Final.May.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.Final.May.Service.LanguageService;

@RestController
public class LanguageController {
	@Autowired
	LanguageService languageService;
}
