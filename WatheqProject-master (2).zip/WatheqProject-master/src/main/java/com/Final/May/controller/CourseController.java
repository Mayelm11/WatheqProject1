package com.Final.May.controller;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Final.May.DTO.CouDTO;
import com.Final.May.Service.CourseService;

@RestController
public class CourseController {

	@Autowired
	CourseService courseService;
	
	CouDTO courseDTO = new CouDTO("p", "p", "p", "p", "p", Timestamp.valueOf("2070-11-12 01:02:03.123456789"),
			Timestamp.valueOf("2090-11-12 01:02:03.123456789"));

	@RequestMapping("/insertCourse")
	public String insertCourse() {
		courseService.createCourseDTO(courseDTO);

		return "Done";

	}


}
