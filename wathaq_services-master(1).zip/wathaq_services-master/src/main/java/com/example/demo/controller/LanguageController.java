package com.example.demo.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.AllLanguageDTO;
import com.example.demo.dto.LanguageDTO;
import com.example.demo.service.LanguageService;

@RestController
@RequestMapping("/language")
public class LanguageController {

	@Autowired
	LanguageService languageService;

	@RequestMapping(method = RequestMethod.POST, path = "/insertlanguage")
	public ResponseEntity<?> insertCompany(@RequestBody LanguageDTO languageDTO) {
		HashMap<String, Object> rv = languageService.createLanguageDTO(languageDTO);
		return ResponseEntity.ok(rv);
	}

	@RequestMapping(method = RequestMethod.POST, path = "/upload", produces = "application/json")
	public ResponseEntity<?> uploadFile(@RequestParam("langid") Long langId, @RequestParam("file") MultipartFile file)
			throws IOException {
		Map<String, Object> data = Collections.singletonMap("response", languageService.upload(langId, file));
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, path = "/filter")
	public ResponseEntity<?> filterCertificateCompany(@RequestParam("indid") Long indId) {
		List<AllLanguageDTO> data = languageService.findAllLanguage(indId);
		return ResponseEntity.ok(data);
	}
}
