package com.example.demo.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.AllCompanyCertificateDTO;
import com.example.demo.dto.AllEduCertificateDTO;
import com.example.demo.dto.CompanyCertificateDTO;
import com.example.demo.dto.EduCertificateDTO;
import com.example.demo.model.Certificate;
import com.example.demo.model.Company;
import com.example.demo.model.EduInstitution;
import com.example.demo.model.Individual;
import com.example.demo.repository.CertificateRepository;
import com.example.demo.repository.CompanyRepository;
import com.example.demo.repository.EduInstitutionRepository;
import com.example.demo.repository.IndividualRepository;

@Service

public class CertificateService {

	@Autowired
	CertificateRepository certificateRepository;
	@Autowired
	IndividualRepository individualRepo;
	@Autowired
	CompanyRepository companyRepo;
	@Autowired
	EduInstitutionRepository eduInstitutionRepo;

	public HashMap<String, Object> createEduCertificateDTO(EduCertificateDTO certificateDTO) {
		HashMap<String, Object> rv = new HashMap<String, Object>();
		Individual ind = individualRepo.findById(certificateDTO.getIndividualId()).get();

		Certificate certificate = Certificate.builder().indID(ind).id(certificateDTO.getId())
				.universityName(certificateDTO.getUniversityName()).universityType(certificateDTO.getUniversityType())
				.addBy(certificateDTO.getAddBy()).graduationDate(certificateDTO.getGraduationDate())
				.gpa(certificateDTO.getGpa()).degree(certificateDTO.getDegree()).major(certificateDTO.getMajor())
				.idType("edu").build();
		Certificate cert = certificateRepository.save(certificate);
		rv.put("response", "ok");
		rv.put("id", cert.getCertificateID());
		return rv;
	}

	public HashMap<String, Object> createCompanyCertificateDTO(CompanyCertificateDTO certificateDTO) {
		HashMap<String, Object> rv = new HashMap<String, Object>();
		Individual ind = individualRepo.findById(certificateDTO.getIndividualId()).get();

		Certificate certificate = Certificate.builder().indID(ind).id(certificateDTO.getId())
				.joinDate(certificateDTO.getJoinDate()).leaveDate(certificateDTO.getLeaveDate())
				.addBy(certificateDTO.getAddBy()).idType("comp").build();
		Certificate cert = certificateRepository.save(certificate);
		rv.put("response", "ok");
		rv.put("id", cert.getCertificateID());
		return rv;
	}

	public List<AllCompanyCertificateDTO> findAllCompany(Long compId, String type) {
		List<AllCompanyCertificateDTO> rv = new ArrayList<AllCompanyCertificateDTO>();
		List<Certificate> data = new ArrayList<Certificate>();
		if (type.equals("ind")) {
			data = certificateRepository.findAllByIndID_indId(compId);
		} else {
			data = certificateRepository.findAllByIdAndIdType(compId, "comp");
		}

		data.forEach(cert -> {
			AllCompanyCertificateDTO dto = new AllCompanyCertificateDTO();
			dto.setCertificateId(cert.getCertificateID());
			dto.setJoinDate(cert.getJoinDate());
			dto.setLeaveDate(cert.getLeaveDate());
			dto.setIndividualName(cert.getIndID().getEmail());

			if (cert.getIdType().equals("edu")) {
				EduInstitution edu = eduInstitutionRepo.findById(cert.getId()).get();
				dto.setEduName(edu.getEduName());
			} else {
				Company comp = companyRepo.findById(cert.getId()).get();
				dto.setCompanyName(comp.getCompanyName());
			}
			rv.add(dto);
		});
		return rv;
	}

	public List<AllEduCertificateDTO> findAllEdu(Long compId, String type) {
		List<AllEduCertificateDTO> rv = new ArrayList<AllEduCertificateDTO>();
		List<Certificate> data = new ArrayList<Certificate>();
		if (type.equals("ind")) {
			data = certificateRepository.findAllByIndID_indId(compId);
		} else {
			data = certificateRepository.findAllByIdAndIdType(compId, "comp");
		}

		data.forEach(cert -> {
			AllEduCertificateDTO dto = new AllEduCertificateDTO();
			dto.setCertificateId(cert.getCertificateID());
			dto.setDegree(cert.getDegree());
			dto.setGpa(cert.getGpa());
			dto.setMajor(cert.getMajor());
			dto.setUniversityName(cert.getUniversityName());
			dto.setUniversityType(cert.getUniversityType());
			dto.setIndividualName(cert.getIndID().getEmail());
			rv.add(dto);
		});
		return rv;
	}

	public Boolean upload(long certificateId, MultipartFile file) throws IOException {
		byte[] arr = file.getBytes();
		Certificate cert = certificateRepository.findById(certificateId).get();
		if (arr != null) {
			if (cert != null) {
				cert.setPdfFile(arr);
				certificateRepository.save(cert);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public byte[] download(Long certId) {
		Certificate cert = certificateRepository.findById(certId).get();
		return cert.getPdfFile();
	}
}
