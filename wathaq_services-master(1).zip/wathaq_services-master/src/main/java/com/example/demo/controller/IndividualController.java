package com.example.demo.controller;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.IndividualDTO;
import com.example.demo.service.IndividualService;

@RestController
@RequestMapping("/individual")
public class IndividualController {

	@Autowired
	IndividualService individualService;

	@RequestMapping(method = RequestMethod.POST, path = "/insertIndividual")
	public ResponseEntity<?> getDomain(@RequestBody IndividualDTO dto) {
		boolean rv = individualService.createIndividualDTO(dto);
		if (rv == true) {
			return ResponseEntity.ok(Collections.singletonMap("response", "ok"));
		} else {
			return ResponseEntity.ok(Collections.singletonMap("response", "error"));
		}
	}

	@RequestMapping("/findIndividual")
	public String findIndividualDTO() {
		try {
			individualService.findById(1L);
			return "Found";
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	@RequestMapping("/deleteIndividual")
	public String deleteIndividual() throws Exception {
		individualService.deleteIndividual(1L);
		return "Deleted";
	}

	@RequestMapping("/updateIndividual")
	public IndividualDTO updateIndividual() throws Exception {
		return individualService.updateAddressIndividualDTO(1L, "258");
	}

	@RequestMapping("/findIndividualDTO")
	public String FindbyID() throws Exception {
		individualService.getById(1L);
		return "Find IndividualDTO";
	}

	@RequestMapping(method = RequestMethod.GET, path = "/filter")
	public ResponseEntity<?> getAllInd() {
		return ResponseEntity.ok(individualService.getAllInd());
	}
}
