package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

@Entity
@Table(name = "certificate")
public class Certificate implements Serializable {

	private static final long serialVersionUID = -3009157732242241606L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "certificateID", unique = true)
	private Long certificateID;

	@ManyToOne(fetch = FetchType.LAZY, optional = false, cascade = CascadeType.ALL)
	@JoinColumn(name = "indID", nullable = false, unique = false)
	private Individual indID;

	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "idType")
	private String idType;

	@Column(name = "relationName")
	private String relationName;

	@Column(name = "universityName")
	private String universityName;

	@Column(name = "universityType")
	private String universityType;

	@Column(name = "addBy")
	private String addBy;

	@Column(name = "graduationDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date graduationDate;

	@Column(name = "gpa")
	private Double gpa;

	@Column(name = "degree")
	private String degree;

	@Column(name = "major")
	private String major;

	@Column(name = "joinDate")
	@Temporal(TemporalType.DATE)
	private Date joinDate;

	@Column(name = "leaveDate")
	@Temporal(TemporalType.DATE)
	private Date leaveDate;

	@Lob
	@Column(name = "pdfFile")
	private byte[] pdfFile;

	@Builder
	public Certificate(Long certificateID, Individual indID, Long id, String relationName, String universityName,
			String universityType, String addBy, Date graduationDate, Double gpa, String degree, String major,
			String idType) {
		this.certificateID = certificateID;
		this.indID = indID;
		this.id = id;
		this.relationName = relationName;
		this.universityName = universityName;
		this.universityType = universityType;
		this.addBy = addBy;
		this.graduationDate = graduationDate;
		this.gpa = gpa;
		this.degree = degree;
		this.major = major;
		this.idType = idType;
	}

	@Builder
	public Certificate(Individual indID, Long id, String addBy, String universityName, Date joinDate, Date leaveDate,
			String idType) {
		this.indID = indID;
		this.id = id;
		this.addBy = addBy;
		this.joinDate = joinDate;
		this.leaveDate = leaveDate;
		this.idType = idType;
	}
}