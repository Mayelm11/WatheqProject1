package com.example.demo.dto;

import java.util.Date;

import com.example.demo.util.dateProviders.JsonDateOnlyDeserializer;
import com.example.demo.util.dateProviders.JsonDateOnlySerializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class EduCertificateDTO {

	private Long individualId;
	private Long id;
	private String universityName;
	private String universityType;
	private String addBy;
	
	@JsonSerialize(using = JsonDateOnlySerializer.class)
	@JsonDeserialize(using = JsonDateOnlyDeserializer.class)
	private Date graduationDate;
	private Double gpa;
	private String degree;
	private String major;
}
