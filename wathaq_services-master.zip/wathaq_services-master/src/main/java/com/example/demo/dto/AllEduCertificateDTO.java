package com.example.demo.dto;

import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AllEduCertificateDTO {

	private String individualName;
	private Long individualId;
	private Long certificateId;
	private String universityName;
	private String universityType;
	private String addBy;
	private Date graduationDate;
	private Double gpa;
	private String degree;
	private String major;
}
