package com.example.demo.util.dateProviders;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * Used to serialize Java.util.Date, which is not a common JSON
 * 
 * @JsonSerialize(using=JsonDateSerializer.class)
 */

public class JsonDateSerializer extends JsonSerializer<Date> {

	private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.US);

	@Override
	public void serialize(Date date, JsonGenerator jgen, SerializerProvider provider) {

		String formattedDate = dateFormat.format(date);
		try {
			jgen.writeString(formattedDate);
		} catch (JsonGenerationException e) {
			// throw new UserMessageException(FinalValues.Message_DateTimeFormatException);
		} catch (IOException e) {
			// throw new UserMessageException(FinalValues.Message_IO_Exception);
		}
	}
}