package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import com.sun.istack.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

@MappedSuperclass
public class WathiqUser {

//	@Email
	@Column(name = "email")
	private String email;

	@NotNull
	@Column(name = "phoneNumber")
//	@Pattern(regexp = "(\\+966|0)[0-9]{9}")
	private String phoneNumber;

	@NotNull
	@Column(name = "address")
	private String address;

	@NotNull
	@Column(name = "password")
	private String password;

	public WathiqUser(String email, String phone_number, String address, String password) {
		this.email = email;
		this.phoneNumber = phone_number;
		this.address = address;
		this.password = password;
	}

}