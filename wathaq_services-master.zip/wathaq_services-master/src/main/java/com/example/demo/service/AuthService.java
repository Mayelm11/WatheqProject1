package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

	@Autowired
	IndividualService individualService;
	@Autowired
	CompanyService companyService;
	@Autowired
	EduInstitutionService eduInstitutionService;

	public Boolean login(String username, String password) {
		Boolean ind = individualService.login(username, password);
		if (ind == true) {
			return true;
		} else {
			Boolean comp = companyService.login(username, password);
			if (comp == true) {
				return true;
			} else {
				// login with Educational.
				return false;
			}
		}
	}

}
