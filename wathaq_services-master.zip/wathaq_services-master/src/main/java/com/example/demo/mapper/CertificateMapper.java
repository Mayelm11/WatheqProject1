package com.example.demo.mapper;

import com.example.demo.dto.EduCertificateDTO;
import com.example.demo.model.Certificate;

public interface CertificateMapper {

	Certificate dtoToDomain(final EduCertificateDTO certificate );
	EduCertificateDTO domainToDto(final Certificate certificate );

}
