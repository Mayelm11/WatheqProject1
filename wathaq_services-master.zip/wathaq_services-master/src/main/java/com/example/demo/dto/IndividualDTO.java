package com.example.demo.dto;

import java.util.Date;

import com.example.demo.util.dateProviders.JsonDateOnlyDeserializer;
import com.example.demo.util.dateProviders.JsonDateOnlySerializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class IndividualDTO {

	private String email;
	private String phoneNumber;
	private String address;
	private String password;
	private String nationalID;
	private String firstName;
	private String middleName;
	private String lastName;
	private String gender;
	private String skills;

	@JsonSerialize(using = JsonDateOnlySerializer.class)
	@JsonDeserialize(using = JsonDateOnlyDeserializer.class)
	private Date dateOfBirth;
	private String attachments;
}
