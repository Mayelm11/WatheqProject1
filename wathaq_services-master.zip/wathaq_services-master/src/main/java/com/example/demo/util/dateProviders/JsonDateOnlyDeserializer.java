package com.example.demo.util.dateProviders;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

/**
 * Used to serialize Java.util.Date, which is not a common JSON
 * 
 * @JsonSerialize(using=JsonDateSerializer.class)
 */

public class JsonDateOnlyDeserializer extends JsonDeserializer<Date> {

	private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

	@Override
	public Date deserialize(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext) {
		String strdate = null;
		try {
			strdate = paramJsonParser.getText().trim();
			return dateFormat.parse(strdate);
		} catch (JsonParseException e1) {
			// throw new UserMessageException(FinalValues.Message_DateTimeFormatException);
		} catch (IOException e1) {
			// throw new UserMessageException(FinalValues.Message_IO_Exception);
		} catch (Exception e) {
			// throw new UserMessageException(FinalValues.Message_General_Exception);
		}
		return paramDeserializationContext.parseDate(strdate);
	}
}