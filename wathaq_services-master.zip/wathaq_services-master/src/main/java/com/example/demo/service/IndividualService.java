package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.AllIndividualDTO;
import com.example.demo.dto.IndividualDTO;
import com.example.demo.exception.NotFoundException;
import com.example.demo.mapperImp.IndividualMapperImp;
import com.example.demo.model.Individual;
import com.example.demo.repository.IndividualRepository;

@Service
@Transactional
public class IndividualService {

	@Autowired
	IndividualRepository individualRepository;
	private static final IndividualMapperImp individualMapper = new IndividualMapperImp();

	public Boolean createIndividualDTO(IndividualDTO individualDTO) {
		Individual exist = individualRepository.findByEmail(individualDTO.getEmail());

		if (exist == null) {
			Individual individual = Individual.builder().email(individualDTO.getEmail())
					.phone_number(individualDTO.getPhoneNumber()).address(individualDTO.getAddress())
					.password(individualDTO.getPassword()).nationalID(individualDTO.getNationalID())
					.firstName(individualDTO.getFirstName()).middleName(individualDTO.getMiddleName())
					.lastName(individualDTO.getLastName()).gender(individualDTO.getGender()).type("ind")
					.skills(individualDTO.getSkills()).dateOfBirth(individualDTO.getDateOfBirth())
					.attachments(individualDTO.getAttachments()).build();

			individualRepository.save(individual);
			return true;
		} else {
			return false;
		}
	}

	public IndividualDTO findById(Long nationalID) throws Exception {
		return individualRepository.findById(nationalID).map(individualMapper::domainToDto)
				.orElseThrow(() -> new Exception("NationalID not found - " + nationalID));
	}

	public void deleteIndividual(Long nationalID) {
		try {
			Individual individual = individualRepository.findById(nationalID).get();
			individualRepository.delete(individual);
		} catch (NoSuchElementException ex) {
			throw new NotFoundException(
					String.format("No Record with the nationalID [%s] was found in our database", nationalID));
		}
	}

	public IndividualDTO updateAddressIndividualDTO(Long nationalID, String address) {
		try {
			individualRepository.updateAddress(nationalID, address);
			return individualRepository.findById(nationalID).map(individualMapper::domainToDto).get();
		} catch (NoSuchElementException ex) {
			throw new NotFoundException(
					String.format("No Record with the nationalID [%s] was found in our database", nationalID));
		}

	}

	public IndividualDTO getById(Long nationalID) {
		try {
			return individualRepository.findById(nationalID).map(individualMapper::domainToDto).get();
		} catch (NoSuchElementException ex) {
			throw new NotFoundException(
					String.format("No Record with the nationalID [%s] was found in our database", nationalID));
		}
	}

	public HashMap<String, Object> login(String username, String password) {
		Individual ind = individualRepository.findByEmail(username);
		HashMap<String, Object> rv = new HashMap<String, Object>();
		if (ind != null) {
			if (password.equals(ind.getPassword())) {
				rv.put("success", true);
				rv.put("id", ind.getIndId());
				rv.put("type", "ind");
				return rv;
			} else {
				rv.put("success", false);
				return rv;
			}
		}
		rv.put("success", false);
		return rv;
	}

	//
	// private static final IndividualMapperImp individualMapper = new
	// IndividualMapperImp();
	//
	// private List<IndividualDTO> individual= new ArrayList<>(Arrays.asList(
	// new IndividualDTO("s","s","s","s","s","s", "s", "s", "s", "s", "s",
	// Timestamp.valueOf("2018-11-12 01:02:03.123456789"),"s"),
	// new IndividualDTO("t","t","t","t","t","t", "t", "t", "t", "t", "t",
	// Timestamp.valueOf("2019-11-12 01:02:03.123456789"),"t")
	//
	// ));
	//
	// public List<IndividualDTO> allIndividualDTO(){
	// return individual;
	// }
	//
	// public boolean save(IndividualDTO individual) {
	// return this.individual.add(individual);
	// }
	//
	// public IndividualDTO findall(IndividualDTO individual) {
	// return this.individual.(individual);
	// }
	//
	// public IndividualDTO toDto(Individual individual) {
	// return individualMapper.domainToDto(individual);
	//
	// }
	// public IndividualDTO getById(String id) {
	// for(IndividualDTO individualDTO: individual ) {
	// if(individualDTO.getNationalID()== id)
	// return individualDTO;
	// }
	// return null;
	// }
	//
	// public Individual toDomain(IndividualDTO individual) {
	// return individualMapper1.dtoToDomain(individual);
	//
	// }

	public List<AllIndividualDTO> getAllInd() {
		List<AllIndividualDTO> allDto = new ArrayList<AllIndividualDTO>();
		individualRepository.findAll().forEach(ind -> {
			if (ind.getType().equals("ind")) {
				AllIndividualDTO dto = new AllIndividualDTO();
				dto.setIndId(ind.getIndId());
				dto.setEmail(ind.getEmail());
				dto.setPhoneNumber(ind.getPhoneNumber());
				dto.setFirstName(ind.getFName());
				dto.setMiddleName(ind.getMName());
				dto.setLastName(ind.getLName());
				allDto.add(dto);
			}
		});
		return allDto;
	}
}
