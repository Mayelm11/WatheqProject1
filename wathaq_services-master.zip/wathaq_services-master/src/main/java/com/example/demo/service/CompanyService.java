package com.example.demo.service;

import java.io.IOException;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.CompanyDTO;
import com.example.demo.mapperImp.CompanyMapperImp;
import com.example.demo.model.Company;
import com.example.demo.repository.CompanyRepository;

@Service
public class CompanyService {

	@Autowired
	private CompanyRepository companyRepository;
	private static final CompanyMapperImp companyMapper = new CompanyMapperImp();

	public HashMap<String, Object> createCompanyDTO(CompanyDTO companyDTO) {
		HashMap<String, Object> rv = new HashMap<String, Object>();
		Company exist = companyRepository.findByEmail(companyDTO.getEmail());
		if (exist == null) {
			Company company = Company.builder().email(companyDTO.getEmail()).phone_number(companyDTO.getPhoneNumber())
					.address(companyDTO.getAddress()).password(companyDTO.getPassword())
					.companyName(companyDTO.getCompanyName()).build();
			Company comp = companyRepository.save(company);
			rv.put("response", "ok");
			rv.put("id", comp.getCompanyRefrence());
		} else {
			rv.put("response", "error");
		}
		return rv;
	}

	public CompanyDTO findById(Long companyRefrence) throws Exception {
		return companyRepository.findById(companyRefrence).map(companyMapper::domainToDto)
				.orElseThrow(() -> new Exception("CompanyRefrence not found - " + companyRefrence));
	}

	public HashMap<String, Object> login(String username, String password) {
		HashMap<String, Object> rv = new HashMap<String, Object>();
		Company comp = companyRepository.findByEmail(username);
		if (comp != null) {
			if (password.equals(comp.getPassword())) {
				rv.put("success", true);
				rv.put("id", comp.getCompanyRefrence());
				rv.put("type", "comp");
				return rv;
			} else {
				rv.put("success", false);
				return rv;
			}
		}
		rv.put("success", false);
		return rv;
	}

	public Boolean upload(long companyId, MultipartFile file) throws IOException {
		byte[] arr = file.getBytes();
		Company comp = companyRepository.findById(companyId).get();
		if (arr != null) {
			if (comp != null) {
				comp.setPdfFile(arr);
				companyRepository.save(comp);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}