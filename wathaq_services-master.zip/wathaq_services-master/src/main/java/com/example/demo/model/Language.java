package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

@Entity
@Table(name = "language")
public class Language implements Serializable {

	private static final long serialVersionUID = -3009157732242241606L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long languge_id;

	@Column(name = "langugeName")
	private String langugeName;

	@Column(name = "addBy")
	private String addBy;

	@Column(name = "langugeDate")
	@Temporal(TemporalType.DATE)
	private Date langugeDate;

	@Column(name = "langugeRefrenceNo")
	private Long langugeRefrenceNo;

	@Column(name = "durationValid")
	private String durationValid;

	@Lob
	@Column(name = "langugeAttach")
	private byte[] langugeAttach;

	@ManyToOne(fetch = FetchType.LAZY, optional = false, cascade = CascadeType.ALL)
	@JoinColumn(name = "indID", nullable = false, unique = false)
	private Individual indID;

	@Builder
	public Language(Individual indID, String langugeName, String addBy, Date langugeDate, long langugeRefrenceNo,
			String durationValid) {
		this.indID = indID;
		this.langugeName = langugeName;
		this.addBy = addBy;
		this.langugeDate = langugeDate;
		this.langugeRefrenceNo = langugeRefrenceNo;
		this.durationValid = durationValid;
	}
}