package com.example.demo.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class AllIndividualDTO {

	private Long indId;
	private String email;
	private String phoneNumber;
	private String firstName;
	private String middleName;
	private String lastName;
}
