package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.sun.istack.NotNull;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor

@Entity
@Table(name = "individual")
public class Individual extends WathiqUser implements Serializable {

	private static final long serialVersionUID = -3009157732242241606L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "indID")
	private Long indId;

	@Column(name = "nationalID")
	private Long nationalID;

	@NotNull
	@Column(name = "fName")
	private String fName;

	@NotNull
	@Column(name = "mName")
	private String mName;

	@NotNull
	@Column(name = "lName")
	private String lName;

	@NotNull
	@Column(name = "gender")
	private String gender;

	@Column(name = "skills")
	private String skills;
	
	@Column(name = "status")
	private String status;

	@Column(name = "dateOfBirth")
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;

	@Column(name = "attachments")
	private String attachments;

	@Builder
	public Individual(String email, String phone_number, String address, String password, String nationalID,
			String firstName, String middleName, String lastName, String gender, String type, String skills, Date dateOfBirth,
			String attachments) {
		super(email, phone_number, address, password, "ind");
		this.fName = firstName;
		this.mName = middleName;
		this.lName = lastName;
		this.gender = gender;
		this.skills = skills;
		this.dateOfBirth = dateOfBirth;
		this.attachments = attachments;
	}
}