package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table(name = "company")
public class Company extends WathiqUser implements Serializable {

	private static final long serialVersionUID = -3009157732242241606L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "companyRefrence")
	private Long companyRefrence;

	@NotNull
	@Column(name = "companyName")
	private String companyName;

	@Column(name = "startDate")
	private Date startDate;

	@Column(name = "endDate")
	private Date endDate;

	public Company(Long companyRefrence, String companyName) {
		this.companyRefrence = companyRefrence;
		this.companyName = companyName;
	}

	@Builder
	public Company(String email, String phone_number, String address, String password, Long companyRefrence,
			String companyName, Date startDate, Date endDate) {
		super(email, phone_number, address, password);
		this.companyRefrence = companyRefrence;
		this.companyName = companyName;
		this.startDate = startDate;
		this.endDate = endDate;
	}

}