package com.example.demo.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class EduInstitutionDTO {

	private String email;
	private String phoneNumber;
	private String address;
	private String password;
	private String eduName;
	private String universityName;
	private String universityType;
}
