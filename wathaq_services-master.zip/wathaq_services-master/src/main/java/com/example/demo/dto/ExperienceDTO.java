package com.example.demo.dto;

import java.sql.Timestamp;

import com.example.demo.model.Company;
import com.example.demo.model.EduInstitution;
import com.example.demo.model.Individual;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ExperienceDTO {

	private Individual indID;
	private Company companyRefrence;
	private EduInstitution eduInstitutionID;
	private Company companyName;
	private String experiencePosition;
	private Timestamp startDate;
	private Timestamp endDate;
	private String addBy;
	private String refrenceName;
	private String refrenceEmail;

	public ExperienceDTO(Individual indID, Company companyRefrence, EduInstitution eduInstitutionID,
			Company companyName, String experiencePosition, Timestamp startDate, Timestamp endDate, String addBy,
			String refrenceName, String refrenceEmail) {
		super();
		this.indID = indID;
		this.companyRefrence = companyRefrence;
		this.eduInstitutionID = eduInstitutionID;
		this.companyName = companyName;
		this.experiencePosition = experiencePosition;
		this.startDate = startDate;
		this.endDate = endDate;
		this.addBy = addBy;
		this.refrenceName = refrenceName;
		this.refrenceEmail = refrenceEmail;
	}
}
