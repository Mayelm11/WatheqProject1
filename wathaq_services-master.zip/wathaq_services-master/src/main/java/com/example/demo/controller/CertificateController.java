package com.example.demo.controller;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CertificateDTO;
import com.example.demo.model.EduInstitution;
import com.example.demo.model.Individual;
import com.example.demo.service.CertificateService;

@RestController
public class CertificateController {

	@Autowired
	CertificateService certificateService;
	Individual individual = new Individual("1090623645");
	EduInstitution eduInstitution = new EduInstitution("22", "22", "22");
	CertificateDTO certificateDTO = new CertificateDTO("test", individual, eduInstitution, eduInstitution,
			eduInstitution, "test", Timestamp.valueOf("2070-11-12 01:02:03.123456789"), 0.0, "test", "test");

	@RequestMapping("/insertCertificate")
	public String process() {
		certificateService.createCertificateDTO(certificateDTO);

		return "Done";

	}

	@RequestMapping("/findCertificate")
	public String findCertificateDTO() {
		try {
			certificateService.findById("");
			return "Found";
		} catch (Exception e) {
			return e.getMessage();
		}

	}
}
