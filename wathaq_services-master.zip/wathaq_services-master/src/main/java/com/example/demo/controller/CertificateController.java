package com.example.demo.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.AllCompanyCertificateDTO;
import com.example.demo.dto.AllEduCertificateDTO;
import com.example.demo.dto.CompanyCertificateDTO;
import com.example.demo.dto.EduCertificateDTO;
import com.example.demo.service.CertificateService;

@RestController
@RequestMapping(path = "/certificate")
public class CertificateController {

	@Autowired
	CertificateService certificateService;

	@RequestMapping(method = RequestMethod.POST, path = "/insertCompanyCertificate")
	public ResponseEntity<?> insertCertificate(@RequestBody CompanyCertificateDTO certificateDTO) {
		return ResponseEntity.ok(certificateService.createCompanyCertificateDTO(certificateDTO));
	}

	@RequestMapping(method = RequestMethod.POST, path = "/insertEduCertificate")
	public ResponseEntity<?> insertCertificate(@RequestBody EduCertificateDTO certificateDTO) {
		return ResponseEntity.ok(certificateService.createEduCertificateDTO(certificateDTO));
	}

	@RequestMapping(method = RequestMethod.GET, path = "/filtercompany")
	public ResponseEntity<?> filterCertificateCompany(@RequestParam("compid") Long Id,
			@RequestParam("type") String type) {
		List<AllCompanyCertificateDTO> data = certificateService.findAllCompany(Id, type);
		return ResponseEntity.ok(data);
	}

	@RequestMapping(method = RequestMethod.GET, path = "/filteredu")
	public ResponseEntity<?> filterCertificateEdu(@RequestParam("compid") Long Id, @RequestParam("type") String type) {
		List<AllEduCertificateDTO> data = certificateService.findAllEdu(Id, type);
		return ResponseEntity.ok(data);
	}

	@RequestMapping(method = RequestMethod.POST, path = "/upload", produces = "application/json")
	public ResponseEntity<?> uploadFile(@RequestParam("certificateid") Long certificateId,
			@RequestParam("file") MultipartFile file) throws IOException {
		Map<String, Object> data = Collections.singletonMap("response", certificateService.upload(certificateId, file));
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, path = "/download", produces = "application/pdf")
	public ResponseEntity<?> downloadFile(@RequestParam("certid") Long certId) {
		return new ResponseEntity<>(certificateService.download(certId), HttpStatus.OK);
	}
}
