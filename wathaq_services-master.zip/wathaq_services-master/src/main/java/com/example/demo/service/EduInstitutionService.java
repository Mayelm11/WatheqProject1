package com.example.demo.service;

import java.io.IOException;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.EduInstitutionDTO;
import com.example.demo.mapperImp.EduInstitutionMapperImp;
import com.example.demo.model.EduInstitution;
import com.example.demo.repository.EduInstitutionRepository;

@Service
public class EduInstitutionService {

	@Autowired
	EduInstitutionRepository eduInstitutionRepository;

	private static final EduInstitutionMapperImp eduInstitutionMapper = new EduInstitutionMapperImp();

	public HashMap<String, Object> createEducationDTO(EduInstitutionDTO eduInstitutionDTO) {
		HashMap<String, Object> rv = new HashMap<String, Object>();
		EduInstitution exist = eduInstitutionRepository.findByEmail(eduInstitutionDTO.getEmail());
		if (exist == null) {
			EduInstitution eduInstitution = EduInstitution.builder().email(eduInstitutionDTO.getEmail())
					.phone_number(eduInstitutionDTO.getPhoneNumber()).address(eduInstitutionDTO.getAddress())
					.password(eduInstitutionDTO.getPassword()).universityName(eduInstitutionDTO.getUniversityName())
					.universityType(eduInstitutionDTO.getUniversityType()).build();

			EduInstitution edu = eduInstitutionRepository.save(eduInstitution);
			rv.put("response", "ok");
			rv.put("id", edu.getEduInstitutionID());
		} else {
			rv.put("response", "error");
		}
		return rv;
	}

	public EduInstitutionDTO findById(Long eduInstitutionID) throws Exception {
		return eduInstitutionRepository.findById(eduInstitutionID).map(eduInstitutionMapper::domainToDto)
				.orElseThrow(() -> new Exception("EduInstitutionID not found - " + eduInstitutionID));
	}

	public HashMap<String, Object> login(String username, String password) {
		HashMap<String, Object> rv = new HashMap<String, Object>();
		EduInstitution edu = eduInstitutionRepository.findByEmail(username);
		if (edu != null) {
			if (password.equals(edu.getPassword())) {
				rv.put("success", true);
				rv.put("id", edu.getEduInstitutionID());
				rv.put("type", "edu");
				return rv;
			} else {
				rv.put("success", false);
				return rv;
			}
		}
		rv.put("success", false);
		return rv;
	}

	public Boolean upload(long eduId, MultipartFile file) throws IOException {
		byte[] arr = file.getBytes();
		EduInstitution edu = eduInstitutionRepository.findById(eduId).get();
		if (arr != null) {
			if (edu != null) {
				edu.setPdfFile(arr);
				eduInstitutionRepository.save(edu);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}
