package com.example.demo.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.AllLanguageDTO;
import com.example.demo.dto.LanguageDTO;
import com.example.demo.mapperImp.LanguageMapperImp;
import com.example.demo.model.Individual;
import com.example.demo.model.Language;
import com.example.demo.repository.IndividualRepository;
import com.example.demo.repository.LanguageRepository;

@Service

public class LanguageService {

	@Autowired
	LanguageRepository languageRepository;
	@Autowired
	IndividualRepository individualRepo;
	private static final LanguageMapperImp languageMapper = new LanguageMapperImp();

	public HashMap<String, Object> createLanguageDTO(LanguageDTO languageDTO) {
		HashMap<String, Object> rv = new HashMap<String, Object>();
		Language language = Language.builder().langugeName(languageDTO.getLangugeName()).addBy(languageDTO.getAddBy())
				.langugeDate(languageDTO.getLangugeDate()).langugeRefrenceNo(languageDTO.getLangugeRefrenceNo())
				.durationValid(languageDTO.getDurationValid()).build();

		Individual ind = individualRepo.findById(languageDTO.getIndID()).get();
		language.setIndID(ind);
		Language lang = languageRepository.save(language);

		rv.put("response", "ok");
		rv.put("id", lang.getLanguge_id());
		return rv;
	}

	public LanguageDTO findById(long languge_id) throws Exception {
		return languageRepository.findById(languge_id).map(languageMapper::domainToDto)
				.orElseThrow(() -> new Exception("Languge_id not found - " + languge_id));
	}

	public List<AllLanguageDTO> findAllLanguage(Long indId) {
		List<AllLanguageDTO> rv = new ArrayList<AllLanguageDTO>();
		List<Language> data = new ArrayList<Language>();

		data = languageRepository.findByIndID_indId(indId);

		data.forEach(lang -> {
			AllLanguageDTO dto = new AllLanguageDTO();
			dto.setAddBy(lang.getAddBy());
			Individual ind = individualRepo.findById(lang.getIndID().getIndId()).get();
			dto.setDurationValid(lang.getDurationValid());
			dto.setLanguge_id(lang.getLanguge_id());
			dto.setLangugeDate(lang.getLangugeDate());
			dto.setLangugeName(lang.getLangugeName());
			dto.setLangugeRefrenceNo(lang.getLangugeRefrenceNo());
			dto.setIndividualName(ind.getEmail());
			dto.setIndividualId(indId);
			rv.add(dto);
		});
		return rv;
	}

	public Boolean upload(long languageId, MultipartFile file) throws IOException {
		byte[] arr = file.getBytes();
		Language comp = languageRepository.findById(languageId).get();
		if (arr != null) {
			if (comp != null) {
				comp.setLangugeAttach(arr);
				languageRepository.save(comp);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}