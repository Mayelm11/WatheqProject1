package com.example.demo.controller;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CompanyDTO;
import com.example.demo.service.CompanyService;

@RestController
@RequestMapping("/company")
public class CompanyController {

	@Autowired
	CompanyService companyService;
//	CompanyDTO companyDTO = new CompanyDTO("rawankh@gmail.com", "0451264317", "Riyadh", "123", "128523", "", null,
//			null);

	@RequestMapping(method = RequestMethod.POST, path = "/insertCompany")
	public ResponseEntity<?> insertCompany(@RequestBody CompanyDTO companyDTO) {
		companyService.createCompanyDTO(companyDTO);
		return ResponseEntity.ok(Collections.singletonMap("response", "ok"));
	}
}
