package com.example.demo.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.CompanyDTO;
import com.example.demo.service.CompanyService;

@RestController
@RequestMapping("/company")
public class CompanyController {

	@Autowired
	CompanyService companyService;

	@RequestMapping(method = RequestMethod.POST, path = "/insertCompany")
	public ResponseEntity<?> insertCompany(@RequestBody CompanyDTO companyDTO) {
		HashMap<String, Object> rv = companyService.createCompanyDTO(companyDTO);
		return ResponseEntity.ok(rv);
	}

	@RequestMapping(method = RequestMethod.POST, path = "/upload", produces = "application/json")
	public ResponseEntity<?> uploadFile(@RequestParam("companyid") Long companyId,
			@RequestParam("file") MultipartFile file) throws IOException {
		Map<String, Object> data = Collections.singletonMap("response", companyService.upload(companyId, file));
		return new ResponseEntity<>(data, HttpStatus.OK);
	}
}
