package com.example.demo.mapperImp;

import org.modelmapper.ModelMapper;

import com.example.demo.dto.EduCertificateDTO;
import com.example.demo.mapper.CertificateMapper;
import com.example.demo.model.Certificate;

public class CertificateMapperImp implements CertificateMapper {

	private ModelMapper modelMapper;

	public CertificateMapperImp() {
		modelMapper = new ModelMapper();
	}

	@Override
	public Certificate dtoToDomain(EduCertificateDTO certificate) {
		return modelMapper.map(certificate,Certificate.class );
	}

	@Override
	public EduCertificateDTO domainToDto(Certificate certificate) {
		return modelMapper.map(certificate,EduCertificateDTO.class );
	}


}
