# Watheq

#Auth Controller
	Login: check username for individual if not exist  then
			check username for company user if not exist  then
				check username for eduInstitution

#Certificate Controller
	insert company certificae: get json from frontend then add it to DB
	insert eduIns certificate: get json from frontend then add it to DB
	filter company requests: return all certificate from type company
	filter eduInst requests: return all certificate from type eduInst
	upload: upload pdf file after call insert company or eduInst
	download: download pdf file from certificate by certificate id
	
#Company Controller
	insert (register) company: get json from frontend then add it to DB
	upload: upload pdf file after call insert company insertion
	
#EduInstitution Controller
	insert (register) Edu: get json from frontend then add it to DB
	upload: upload pdf file after call insert edu insertion
	
#Individual Controller
	insert (register) individual: get json from frontend then add it to DB
	filter requests: return all individual certificates of type edu or company
	
#Language Controller
	insert language: get json from frontend then add it to DB
	upload: upload pdf file after call insert language
	filter requests: return all language certificates
